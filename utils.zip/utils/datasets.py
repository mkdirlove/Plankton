# dataset.py

import sys
import os

# Add yolov5 directory to the path if necessary
sys.path.append('path_to_yolov5')  # Change 'path_to_yolov5' to the correct path

# Import YOLOv5 utilities
from yolov5.utils.datasets import LoadImages, LoadStreams
from yolov5.utils.torch_utils import select_device
from yolov5.utils.general import check_img_size, non_max_suppression, scale_coords
from yolov5.utils.plots import plot_one_box
import torch

# Define the weights and source paths
weights = 'yolov5s.pt'  # Replace with the correct model weights path
source = 'data/images'  # Replace with your image source path (could be a folder or video URL)

# Initialize the device (CPU or GPU)
device = select_device('cpu')  # Use 'cpu' or '0' for GPU if available

# Initialize the dataset loader (for image loading)
dataset = LoadImages(source, img_size=640, stride=32)

# Optionally, initialize a video stream loader (if using video input)
# dataset = LoadStreams(source, img_size=640, stride=32)

# Model inference logic
def detect(weights, source, conf_thres=0.4, save_txt=False, device='cpu'):
    # Load model weights
    model = torch.load(weights, map_location=device)['model'].float()  # Load the model
    model.to(device).eval()

    # Iterate over dataset
    for path, img, im0s, vid_cap in dataset:
        # Apply inference (model prediction)
        img = torch.from_numpy(img).to(device)  # Convert the image to tensor
        img = img.float() / 255.0  # Normalize
        if len(img.shape) == 3:
            img = img[None]  # Add batch dimension if necessary

        # Perform inference
        pred = model(img, augment=False)[0]
        pred = non_max_suppression(pred, conf_thres, 0.5)  # Apply NMS

        # Process results
        for det in pred:
            if len(det):
                # Rescale boxes to original image
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0s.shape).round()

                # Print results
                for *xyxy, conf, cls in det:
                    label = f'{dataset.names[int(cls)]} {conf:.2f}'
                    print(f'{label} at {xyxy}')

                    # Optionally, save results to txt file
                    if save_txt:
                        pass  # Implement saving logic if needed

                    # Optionally, plot boxes on the image
                    plot_one_box(xyxy, im0s, label=label, color=(255, 0, 0), line_thickness=2)

        # Display image (or video frame)
        cv2.imshow('Result', im0s)  # OpenCV window to display result
        cv2.waitKey(1)  # Add a short delay to update window

# Run the detection
detect(weights=weights, source=source, conf_thres=0.4, save_txt=False, device=device)

